package net.vulkanmod.mixin.render;

import com.google.common.collect.ImmutableList;
import net.minecraft.class_1921;
import net.minecraft.class_4668;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1921.class_4688.class)
public interface CompositeStateAccessor {

    @Accessor("textureState")
    class_4668.class_5939 getTextureState();

    @Accessor("outputState")
    class_4668.class_4678 getOutputState();

    @Accessor("outlineProperty")
    class_1921.class_4750 getOutlineProperty();

    @Accessor("states")
    ImmutableList<class_4668> getStates();
}
