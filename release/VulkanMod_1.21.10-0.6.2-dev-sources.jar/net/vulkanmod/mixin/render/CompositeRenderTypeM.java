package net.vulkanmod.mixin.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.class_11219;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import net.minecraft.class_9801;
import net.vulkanmod.render.engine.*;
import net.vulkanmod.vulkan.Renderer;
import net.vulkanmod.vulkan.VRenderSystem;
import net.vulkanmod.vulkan.texture.VTextureSelector;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.OptionalDouble;
import java.util.OptionalInt;

@Mixin(class_1921.class_4687.class)
public abstract class CompositeRenderTypeM {

    @Shadow @Final private class_1921.class_4688 state;
    @Shadow @Final private RenderPipeline renderPipeline;

    // TODO
    /**
     * @author
     * @reason
     */
    @Overwrite
    public void draw(class_9801 meshData) {
        ((class_1921.class_4687)(Object)(this)).method_23516();
        GpuBufferSlice gpuBufferSlice = RenderSystem.getDynamicUniforms()
                                                    .method_71106(
                                                            RenderSystem.getModelViewMatrix(),
                                                            new Vector4f(1.0F, 1.0F, 1.0F, 1.0F),
                                                            new Vector3f(),
                                                            RenderSystem.getTextureMatrix(),
                                                            RenderSystem.getShaderLineWidth()
                                                    );
        class_9801 var3 = meshData;

        try {
            GpuBuffer gpuBuffer = this.renderPipeline.getVertexFormat().uploadImmediateVertexBuffer(meshData.method_60818());
            GpuBuffer gpuBuffer2;
            VertexFormat.class_5595 indexType;
            if (meshData.method_60821() == null) {
                RenderSystem.class_5590 autoStorageIndexBuffer = RenderSystem.getSequentialBuffer(meshData.method_60822().comp_752());
                gpuBuffer2 = autoStorageIndexBuffer.method_68274(meshData.method_60822().comp_751());
                indexType = autoStorageIndexBuffer.method_31924();
            } else {
                gpuBuffer2 = this.renderPipeline.getVertexFormat().uploadImmediateIndexBuffer(meshData.method_60821());
                indexType = meshData.method_60822().comp_753();
            }

            class_276 renderTarget = ((CompositeStateAccessor)(Object)this.state).getOutputState().method_68491();
            GpuTextureView gpuTextureView = RenderSystem.outputColorTextureOverride != null
                    ? RenderSystem.outputColorTextureOverride
                    : renderTarget.method_71639();
            GpuTextureView gpuTextureView2 = renderTarget.field_1478
                    ? (RenderSystem.outputDepthTextureOverride != null ? RenderSystem.outputDepthTextureOverride : renderTarget.method_71640())
                    : null;

            try (RenderPass renderPass = RenderSystem.getDevice()
                                                     .createCommandEncoder()
                                                     .createRenderPass(() -> "Immediate draw for " +
                                                                             ((class_1921.class_4687) (Object) (this)).method_68484(),
                                                                       gpuTextureView, OptionalInt.empty(), gpuTextureView2, OptionalDouble.empty())) {
                renderPass.setPipeline(this.renderPipeline);
                class_11219 scissorState = RenderSystem.getScissorStateForRenderTypeDraws();
                if (scissorState.method_72091()) {
                    renderPass.enableScissor(scissorState.method_72092(), scissorState.method_72093(), scissorState.method_72094(), scissorState.method_72095());
                }

                RenderSystem.bindDefaultUniforms(renderPass);
                renderPass.setUniform("DynamicTransforms", gpuBufferSlice);
                renderPass.setVertexBuffer(0, gpuBuffer);

                for (int i = 0; i < 12; i++) {
                    GpuTextureView gpuTextureView3 = RenderSystem.getShaderTexture(i);
                    if (gpuTextureView3 != null) {
                        renderPass.bindSampler("Sampler" + i, gpuTextureView3);

                        VkGpuTexture vkGpuTexture = (VkGpuTexture) gpuTextureView3.texture();
                        VTextureSelector.bindTexture(i, vkGpuTexture.getVulkanImage());
                    }
                }

                VRenderSystem.applyModelViewMatrix(RenderSystem.getModelViewMatrix());
                VRenderSystem.calculateMVP();

                renderPass.setIndexBuffer(gpuBuffer2, indexType);

                VkCommandEncoder commandEncoder = (VkCommandEncoder) RenderSystem.getDevice().createCommandEncoder();
                commandEncoder.trySetup((VkRenderPass) renderPass);

                Renderer.getDrawer().draw(meshData.method_60818(), meshData.method_60821(), meshData.method_60822().comp_752(), meshData.method_60822().comp_749(), meshData.method_60822().comp_750());
            }
        } catch (Throwable var17) {
            if (meshData != null) {
                try {
                    var3.close();
                } catch (Throwable var14) {
                    var17.addSuppressed(var14);
                }
            }

            throw var17;
        }

        if (meshData != null) {
            meshData.close();
        }

        ((class_1921.class_4687)(Object)(this)).method_23518();
    }

}
