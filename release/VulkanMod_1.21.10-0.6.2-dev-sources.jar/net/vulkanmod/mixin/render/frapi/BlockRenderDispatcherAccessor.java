package net.vulkanmod.mixin.render.frapi;

import java.util.function.Supplier;
import net.minecraft.class_10418;
import net.minecraft.class_324;
import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_776.class)
public interface BlockRenderDispatcherAccessor {
    @Accessor("specialBlockModelRenderer")
    Supplier<class_10418> getBlockEntityModelsGetter();

    @Accessor("blockColors")
    class_324 getBlockColors();
}
