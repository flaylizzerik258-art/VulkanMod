package net.vulkanmod.mixin.render;

import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(class_757.class)
public abstract class GameRendererMixin {

    /**
     * @author
     * @reason
     */
    @Overwrite
    public float getDepthFar() {
//        return this.getRenderDistance() * 4.0F;
        return Float.POSITIVE_INFINITY;
    }

}
