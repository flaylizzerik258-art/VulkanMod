package net.vulkanmod.mixin.util;

import net.minecraft.class_1011;
import net.minecraft.class_276;
import net.minecraft.class_318;
import net.vulkanmod.vulkan.util.ScreenshotUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.function.Consumer;

@Mixin(class_318.class)
public class ScreenshotMixin {

    @Overwrite
    public static void takeScreenshot(class_276 renderTarget, int mipLevel, Consumer<class_1011> consumer) {
        ScreenshotUtil.takeScreenshot(renderTarget, mipLevel, consumer);
    }

}
