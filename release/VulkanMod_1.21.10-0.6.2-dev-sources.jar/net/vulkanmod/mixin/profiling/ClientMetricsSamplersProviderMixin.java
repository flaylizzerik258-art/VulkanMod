// In a new file, e.g., ClientMetricsSamplersProviderMixin.java
package net.vulkanmod.mixin.profiling; // Or an appropriate package

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Optional;
import net.minecraft.class_6412;
import net.minecraft.class_7168;

@Mixin(class_6412.class)
public class ClientMetricsSamplersProviderMixin {

    @Redirect(method = "registerStaticSamplers", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/TimerQuery;getInstance()Ljava/util/Optional;"))
    private Optional<class_7168> preventTimerQuery() {
        return Optional.empty();
    }
}