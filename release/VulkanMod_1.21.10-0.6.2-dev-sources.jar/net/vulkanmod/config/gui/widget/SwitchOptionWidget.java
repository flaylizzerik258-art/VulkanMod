package net.vulkanmod.config.gui.widget;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.vulkanmod.config.gui.render.GuiRenderer;
import net.vulkanmod.config.option.SwitchOption;
import net.vulkanmod.vulkan.util.ColorUtil;

public class SwitchOptionWidget extends OptionWidget<SwitchOption> {
    private boolean focused;

    public SwitchOptionWidget(SwitchOption option, class_2561 name) {
        super(option, name);
        updateDisplayedValue();
    }

    @Override
    protected void renderControls(double mouseX, double mouseY) {
        int center = controlX + controlWidth / 2;
        int halfWidth = 12;
        int x0 = center - halfWidth;
        int y0 = y + 4;
        int height = this.height - 8;
        int color;

        int w1 = halfWidth - 4;
        int h1 = height - 4;
        if (this.option.getNewValue()) {
            int x1 = x0 + halfWidth + 2;

            color = ColorUtil.ARGB.pack(0.4f, 0.4f, 0.4f, 1.0f);
            GuiRenderer.fillBox(x0 + 2, y0 + 2, x1 - (x0 + 2) - 1, h1, color);

            color = ColorUtil.ARGB.pack(1.0f, 1.0f, 1.0f, 1.0f);
            GuiRenderer.fillBox(x1, y0 + 2, w1, h1, color);
        } else {
            color = ColorUtil.ARGB.pack(1.0f, 1.0f, 1.0f, 0.4f);
            GuiRenderer.fillBox(x0 + 2, y0 + 2, w1, h1, color);
        }

        color = ColorUtil.ARGB.pack(0.6f, 0.6f, 0.6f, 1.0f);
        GuiRenderer.renderBoxBorder(x0, y0, halfWidth * 2, height, 1,  color);

        color = this.active ? 0xFFFFFFFF : 0xFFA0A0A0;
        class_327 textRenderer = class_310.method_1551().field_1772;
        int margin = Math.max(
                textRenderer.method_1727(class_2561.method_43471("options.on").getString()) / 3,
                textRenderer.method_1727(class_2561.method_43471("options.off").getString()) / 3
        );

        int x = this.controlX + this.controlWidth / 2 - (int) (halfWidth * 1.5f) - 4 - margin;
        int y = this.y + (this.height - 8) / 2;
        GuiRenderer.drawCenteredString(textRenderer, this.getDisplayedValue(), x, y, color);
    }

    public void onClick(double mouseX, double mouseY) {
        this.option.setNewValue(!this.option.getNewValue());
        updateDisplayedValue();
    }

    @Override
    public void onRelease(double mouseX, double mouseY) {

    }

    @Override
    protected void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {

    }

    protected void updateDisplayedValue() {
        this.displayedValue = option.getNewValue()
                ? class_2561.method_43471("options.on")
                : class_2561.method_43471("options.off");
    }

    @Override
    public void method_25365(boolean bl) {
        this.focused = bl;
    }

    @Override
    public boolean method_25370() {
        return this.focused;
    }

}
