package net.vulkanmod.config.option;

import net.minecraft.class_2561;
import net.vulkanmod.config.gui.widget.OptionWidget;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public abstract class Option<T> {
    protected final class_2561 name;
    protected class_2561 tooltip;

    protected Consumer<T> onApply;
    protected Supplier<T> valueSupplier;

    protected T value;
    protected T newValue;

    protected Function<T, class_2561> translator;

    OptionWidget<?> widget;

    protected boolean active;
    protected Runnable onChange;
    protected Supplier<Boolean> activationFn;

    public Option(class_2561 name, Consumer<T> setter, Supplier<T> getter, Function<T, class_2561> translator) {
        this.name = name;

        this.onApply = setter;
        this.valueSupplier = getter;

        this.newValue = this.value = this.valueSupplier.get();

        this.translator = translator;
    }

    public Option(class_2561 name, Consumer<T> setter, Supplier<T> getter) {
        this.name = name;

        this.onApply = setter;
        this.valueSupplier = getter;

        this.newValue = this.value = this.valueSupplier.get();
    }

    public Option<T> setOnApply(Consumer<T> onApply) {
        this.onApply = onApply;
        return this;
    }

    public Option<T> setValueSupplier(Supplier<T> supplier) {
        this.valueSupplier = supplier;
        return this;
    }

    public Option<T> setTranslator(Function<T, class_2561> translator) {
        this.translator = translator;
        return this;
    }

    public Option<T> setActive(boolean active) {
        this.active = active;
        this.widget.active = active;
        return this;
    }

    abstract OptionWidget<?> createWidget();

    public OptionWidget<?> getWidget() {
        if (this.widget == null) {
            this.widget = this.createWidget();
        }

        return this.widget;
    }

    public void setNewValue(T t) {
        this.newValue = t;

        if (onChange != null)
            onChange.run();
    }

    public void updateActiveState() {
        if (this.activationFn != null) {
            this.active = this.activationFn.get();
        }
        else {
            this.active = true;
        }

        this.widget.setActive(this.active);
    }

    public class_2561 getName() {
        return this.name;
    }

    public void setOnChange(Runnable runnable) {
        onChange = runnable;
    }

    public void setActivationFn(Supplier<Boolean> activationFn) {
        this.activationFn = activationFn;
    }

    public boolean isChanged() {
        return !this.newValue.equals(this.value);
    }

    public void apply() {
        onApply.accept(this.newValue);
        this.value = this.newValue;
    }

    public T getNewValue() {
        return this.newValue;
    }

    public class_2561 getDisplayedValue() {
        return this.translator.apply(this.newValue);
    }

    public Option<T> setTooltip(class_2561 text) {
        this.tooltip = text;
        return this;
    }

    public class_2561 getTooltip() {
        return this.tooltip;
    }
}
